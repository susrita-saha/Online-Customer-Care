/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/servlet6_2"})
public class servlet6_2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession sess=request.getSession(true);
        String sqlquery,htmlcode="";
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection con=DriverManager.getConnection("jdbc:odbc:cqtdsn");
            sqlquery="select Query,Solution from QueryInfo where Dept=? and not (Solution='un')";
            PreparedStatement stmt=con.prepareStatement(sqlquery,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1,sess.getAttribute("user").toString());
            ResultSet pointer=stmt.executeQuery();
            htmlcode+="<link href='css/servlet6.css' rel='stylesheet'/>";
            htmlcode+="<div id='tablecontainer'>";
            htmlcode+="<table border='0' cellspacing='10' align='center' style='margin:auto'>";
            htmlcode+="<tr>";
            if (pointer.next()==false){
               htmlcode+="<td align='center'>No Previous Solutions</td></tr></table></div>";
               
               return;
           }
           pointer.beforeFirst();
            htmlcode+="<th>Query</th>";
            htmlcode+="<th>Solution</th>";
            htmlcode+="</tr>";
            
            while (pointer.next()){
                htmlcode+="<tr>";
                htmlcode+="<td>"+pointer.getString(1)+"</td>";
                htmlcode+="<td>"+pointer.getString(2)+"</td>";
                htmlcode+="</tr>";
            }
         htmlcode+="</table>";
         htmlcode+="</div>";
            
            
        }
        catch(Exception e){
            out.println("Some internal error occured. Unable to fetch data");
        }
        finally{
            out.println(htmlcode);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
