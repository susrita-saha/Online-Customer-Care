/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.SQLException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/save"})
public class save extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
           try{
           String name=request.getParameter("text1");
           String email=request.getParameter("text2");
           String contact=request.getParameter("text3");
           String custquery=request.getParameter("text4");
           String sqlquery1,sqlquery2,sqlquery3;
            
            
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                Connection con=DriverManager.getConnection("jdbc:odbc:cqtdsn");
                java.util.Calendar cal = java.util.Calendar.getInstance();
                java.util.Date utilDate = cal.getTime();
                java.sql.Date sqlDate = new Date(utilDate.getTime());              
                
                sqlquery1="insert QueryInfo values(?,?,'un','un')";
                sqlquery2="select QueryId from QueryInfo where Query=? and QueryDate=?";
                sqlquery3="insert CustomerInfo values(?,?,?,?)";
                PreparedStatement stmt1=con.prepareStatement(sqlquery1);
                PreparedStatement stmt2=con.prepareStatement(sqlquery2);
                PreparedStatement stmt3=con.prepareStatement(sqlquery3);
                stmt1.setString(1,sqlDate.toString());
                stmt1.setString(2,custquery);
                
                
               
                stmt1.executeUpdate();
                
                stmt2.setString(1,custquery);
                stmt2.setString(2,sqlDate.toString());
                
                ResultSet rs = stmt2.executeQuery();
                rs.next();
                int id=Integer.parseInt(rs.getString(1));
                            
                stmt3.setString(2,name);
                stmt3.setString(3,email);
                stmt3.setString(4,contact);
                stmt3.setInt(1,id);
                stmt3.executeUpdate();
                
                String test=""+id;
                request.setAttribute("i",test);
                RequestDispatcher req=request.getRequestDispatcher("page3.jsp");
                req.forward(request, response);
                
                
              //  response.sendRedirect("page3.jsp");
                
                
               /* String queryb="select QueryId from QueryInfo where Query='custquery' and QueryDate='sqlDate'";
                
                PreparedStatement obj=con.prepareStatement(queryb);
                ResultSet rs = obj.executeQuery();
                String id = rs.getString("QueryId");*/
               
               // out.println("Your Id is:"+id);
            }
            catch(Exception ee)
            {
                out.println("<span style='color:red;'>"+ee.getMessage()+"<br/>Unable to fetch Query ID</span>");
                out.println("<a href='page2.jsp'>Back</a>");
            }
           
        finally{
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(save.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(save.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        }  catch (SQLException ex) {
            Logger.getLogger(save.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(save.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
