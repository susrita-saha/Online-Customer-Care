/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function valid(){
    
    var id,pass;
    id=document.getElementById("text1").value;
    pass=document.getElementById("pass1").value;
    
    //alert(pas);
    //return false;
   
    if (pass===""||id===""){
        document.getElementById("blank").innerHTML="No field should be empty.";
       return false;
    }
    else{
        return true;
          /*  if (("hr"===id&&"hr"===pass)||("hw"===id&&"hw"===pass)||("sw"===id&&"sw"===pass)||("ot"===id&&"ot"===pass)||("admin"===id&&"admin"===pass)){
               return true;
            }
            else {
                document.getElementById("blank").innerHTML="Invalid username or password.";
                return false;
            }*/
    }
}

function noerror(){
    document.getElementById("blank").innerHTML="";
}
/*function validDept(curform){
    
    curform.getElementById("dep").value;
  /* if (dep==="choose"){
       alert ("Please choose a valid department"); 
        return false;
    }
   return true;
   // return false;
   //alert("Hi");
   return false;
}*/