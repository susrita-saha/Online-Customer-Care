/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    function func(qid){
        
        sol=document.getElementById("sol"+qid).value;
        $.post("servlet6_4",{"qid":qid,"sol":sol},function(data){
              $("#row"+qid).html("<td colspan='5' align='center'>"+data+"</td>");
        });
    }
function func1(qid){
        
        $("#sol"+qid).css("display","inline");
        //$("#hyp"+qid).text("Update");
        $("#data"+qid).html("<a id=hyp"+qid+" href='#' onclick='func("+qid+")'>Update</a><a href='#' onclick='func2("+qid+")'>Cancel</a>");
        
    }
    function func2(qid){
        $("#sol"+qid).css("display","none");
        $("#data"+qid).html("<a id=hyp"+qid+" href='#' onclick='func1("+qid+")'>Add Solution</a>");
    }





