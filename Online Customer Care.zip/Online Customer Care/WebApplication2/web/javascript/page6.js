/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function(){
    var htmlcode,i,num;
    $("#curtask").click(function(){
        $("#curtask").html("<a id='curtask' href='#'>Click Here</a><div id='slide' style='display:inline'><a id='minim' href='#'>Minimize/Maximize table</a></div>");
        $("#minim").css("float","right");
        $("#minim").click(function(){
            $("#db1").slideToggle(2000);
        });
        $("#main").css("line-height","300%");
        
        $.post("servlet6_5",{},function(htmlcode){
            $("#db1").html(htmlcode);
        });
    });
    
    $("#prevtask").click(function(){
        $("#prevtask").html("<a id='prevtask' href='#'>Click Here</a><div id='slide' style='display:inline'><a id='minim1' href='#'>Minimize/Maximize table</a></div>");
        $("#minim1").css("float","right");
        $("#minim1").click(function(){
            $("#db2").slideToggle(2000);
        });
        $("#main").css("line-height","300%");
        $.post("servlet6_2",{},function(htmlcode){
            //alert("working");
            $("#db2").html(htmlcode);
        });
    });
});