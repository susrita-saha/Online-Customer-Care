/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function(){
    htmlcode="Please enter Query ID.";
    $("#show").click(function(){
        if ($("#text1").val()===""){
            $("#result").html("<br/>"+htmlcode).css("text-align","center").css("line-height","25px").css("color","red").css("font-style","italic").css("font-size","12px");
        }
        else{
        $.post("servlet4",{"QID":$("#text1").val()},function(htmlcode){
            $("#result").html("<br/>"+htmlcode).css("text-align","center").css("line-height","25px").css("color","maroon").css("font-weight","bold").css("font-style","default").css("font-size","25px");
        });
    }
    });
});

